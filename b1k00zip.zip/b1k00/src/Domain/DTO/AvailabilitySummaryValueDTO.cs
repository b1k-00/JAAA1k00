﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.DTO;
public class AvailabilitySummaryValueDTO
{
    public string StartTime { get; set; }

    public int UserCount { get; set; }
}
