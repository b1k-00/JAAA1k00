﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Application;

namespace Models
{
    public class User
    {
        //this will depend on our user fields
        //will depend on libby required fields
        // username (email) & password are most important currently


        public string Email { get; set; }
        //a.m   type   name     param?
        public string Password { get; set; }
        //a.m    type    name      properties
    }
}
