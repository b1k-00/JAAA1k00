﻿namespace Application.DTOs.DadJoke;

public class CreateDadJokeDTO
{
    public string Setup { get; set; }
    public string Punchline { get; set; }
    public int? Rating { get; set; }
}
