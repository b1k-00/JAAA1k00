﻿namespace Application.DTOs.DadJoke;

public class DadJokeRatingDTO : BaseDTO
{
    public int Rating { get; set; }
}
