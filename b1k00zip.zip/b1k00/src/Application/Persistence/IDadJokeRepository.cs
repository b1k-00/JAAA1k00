﻿using Domain;

namespace Application.Persistence;

/// <summary>
/// Defines the contract used by any implementation of the DadJoke repository
/// </summary>
public interface IDadJokeRepository : IGenericRepository<DadJoke>
{
    //Any additional operations beyond those defined in the IGenericRepository would be added to this interface
    Task RateDadJokeAsync(int dadJokeId, int rating);
}
